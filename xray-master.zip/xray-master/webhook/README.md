# webhook

xray 邀你一起玩转 webhook

https://mp.weixin.qq.com/s/JGN_zfFr-VKXFd4Xt_rZ6A

## 开发说明

 - 需要 Python `3.7` 及以上版本
 - `plugins/demo.py` 给了一个样例，可以先仿照那个去写，数据类型见类型标注