在符合以下条件的情况下，我们欢迎任何人以任何形式使用本项目（包括商用）。

 - 注明集成了本项目（注明方式： 在项目介绍页附上本项目 repo 地址）
 - 同意 https://github.com/chaitin/xray/blob/master/Disclaimer.md 免责声明

