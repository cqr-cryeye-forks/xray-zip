# 测试靶场


这里依靠社区力量收集了几个常用的靶站，可以通过 docker/docker-compose 一键启用。活动开始后，我们注意到在这个repo 中 https://github.com/c0ny1/vulstudy ，作者已经收集了 12 个靶站，这些靶站基本符合我们的要求，所以后续提交中与该 repo 中靶站有所重复的将不再收录。

已有的靶站列表:

- DVWA
- bWAPP
- sqli-labs
- mutillidae
- BodgeIt
- WackoPicko
- WebGoat
- Hackademic
- XSSed
- DSVW
- vulnerable-node
- MCIR
